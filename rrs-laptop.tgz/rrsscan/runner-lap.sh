#!/bin/sh
# laptop RRS scanner that phones home to the VPS edge sink after every state change
cd "$(dirname "$0")"
SINK="http://51.38.36.86:8460/rrscan"
while read s; do
  d="done/${s}"; [ -f "$d" ] && continue
  touch "$d.part"
  curl -sS --max-time 20 "$SINK/START/$s" -o /dev/null || true
  echo "START $s $(date)" >> scan.log
  python3 scan4.py "$s" >> scan.log 2>&1
  rc=$?
  if grep -qE "^${s}	(DONE|ERROR)" scan.log 2>/dev/null || [ $rc -eq 0 ]; then
    mv "$d.part" "$d" 2>/dev/null
    tag=DONE
  else
    rm -f "$d.part"
    tag=RETRYNEXT
  fi
  if grep -q HIT "$s" scan.log 2>/dev/null; then tag="HIT-IN-$s"; fi
  curl -sS --max-time 20 "$SINK/$tag/$s" -o /dev/null || true
  echo "FINISH $tag $s" >> scan.log
done < laptop-queue.txt
echo "ALLDONE $(date)" >> scan.log
curl -sS --max-time 20 "$SINK/ALLDONE" -o /dev/null || true
