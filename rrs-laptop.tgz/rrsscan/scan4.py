import sys, os, re, urllib.request, zipfile, concurrent.futures
HERE=os.path.dirname(os.path.abspath(__file__))
shard=sys.argv[1]
zipname=shard+".zip"
url=f"https://archive.org/download/{shard}/{zipname}"
p=os.path.join(HERE,zipname)
PARTS=24

size=None
req=urllib.request.Request(url, headers={"Range":"bytes=0-0","User-Agent":"uwu/1"})
with urllib.request.urlopen(req, timeout=60) as r:
    cr=r.headers.get("Content-Range","")
    size=int(cr.split("/")[-1]) if cr else None
if not size: raise RuntimeError("no size")

HEX32=re.compile(rb'[0-9a-f]{32}')
KEY25=re.compile(rb'[a-z0-9]{25}')

def dl_range(a,b):
    fd=os.open(p, os.O_WRONLY|os.O_CREAT)
    try:
        req=urllib.request.Request(url, headers={"Range":f"bytes={a}-{b}","User-Agent":"uwu/1"})
        r=urllib.request.urlopen(req, timeout=600)
        off=a
        while True:
            chunk=r.read(1<<16)
            if not chunk: break
            os.pwrite(fd, chunk, off)
            off+=len(chunk)
    finally:
        os.close(fd)

try:
    if not os.path.exists(p):
        os.close(os.open(p, os.O_WRONLY | os.O_CREAT, 0o644))
        os.truncate(p, size)
        with concurrent.futures.ThreadPoolExecutor(PARTS) as ex:
            bounds=[(i*size//PARTS,(i+1)*size//PARTS-1) for i in range(PARTS)]
            def go(): return None
            list(ex.map(dl_range, [a for a,_ in bounds], [b for _,b in bounds]))
    z=zipfile.ZipFile(p)
    needles=[l.strip().encode('latin1') for l in open(os.path.join(HERE,"needles.txt")) if l.strip()]
    raw=[]
    for n in needles:
        try: raw.append(bytes.fromhex(n.decode()))
        except Exception: pass
    needles=needles+raw
    tokpath=os.path.join(HERE,"tokens.tsv")
    for name in z.namelist():
        try: data=z.read(name)
        except Exception: continue
        hits=[n.decode('latin1') for n in needles if n in data]
        if hits: print(f"{shard}\tHIT\t{name}\t{hits}", flush=True)
        try:
            hex32=sorted({m.group(0).decode() for m in HEX32.finditer(data)})[:24]
            keys25=sorted({m.group(0).decode() for m in KEY25.finditer(data) if not m.group(0).startswith(b"0000")})[:24]
        except MemoryError:
            hex32, keys25 = [], []
        if hex32 or keys25 or hits:
            with open(tokpath,"a") as tf:
                tf.write("\t".join([shard, name.split(".")[0], ";".join(hits), ";".join(hex32), ";".join(keys25)])+"\n")
    os.remove(p)
    print(f"{shard}\tDONE", flush=True)
except Exception as e:
    print(f"{shard}\tERROR\t{e}", flush=True)
    try: os.remove(p)
    except: pass
